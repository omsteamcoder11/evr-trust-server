--
-- PostgreSQL database dump
--

\restrict mDN3Yc3Okr4W7n5pEHJSmyvqRfVVV2OKpPqxwM9mbi6cggymxGaNjAnOWnzufMA

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    title character varying(200),
    image_url character varying(255),
    category character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    content text DEFAULT ''::text
);


--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: activity_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_photos (
    id integer NOT NULL,
    category text NOT NULL,
    photo_url text NOT NULL,
    r2_key text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: activity_photos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_photos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activity_photos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_photos_id_seq OWNED BY public.activity_photos.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'admin'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(20),
    message text,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id integer NOT NULL,
    donor_name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(20),
    amount numeric(10,2) NOT NULL,
    purpose character varying(200),
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    razorpay_order_id character varying(100),
    razorpay_payment_id character varying(100)
);


--
-- Name: donations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.donations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: donations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.donations_id_seq OWNED BY public.donations.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    event_date date,
    location character varying(200),
    image_url character varying(255),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    event_time character varying(100)
);


--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: gallery; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery (
    id integer NOT NULL,
    title character varying(255) DEFAULT 'Gallery photo'::character varying NOT NULL,
    image_url text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gallery_id_seq OWNED BY public.gallery.id;


--
-- Name: member_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_number_seq
    START WITH 1001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    father_name character varying(150) NOT NULL,
    date_of_birth date NOT NULL,
    age integer NOT NULL,
    education character varying(100) NOT NULL,
    voter_id character varying(30) NOT NULL,
    assembly_constituency character varying(150) NOT NULL,
    polling_booth character varying(150) NOT NULL,
    mobile character varying(15) NOT NULL,
    whatsapp character varying(15) NOT NULL,
    email character varying(150) NOT NULL,
    address text NOT NULL,
    pincode character varying(10) NOT NULL,
    state character varying(100) NOT NULL,
    city character varying(100) NOT NULL,
    area character varying(150) NOT NULL,
    id_photo_url text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    membership_type text DEFAULT ''::text,
    aadhaar text DEFAULT ''::text,
    payment_status character varying(20) DEFAULT 'paid'::character varying NOT NULL,
    utr character varying(12),
    member_number character varying(20),
    card_token character varying(64),
    paid_at timestamp with time zone,
    razorpay_order_id text,
    razorpay_payment_id text,
    amount_paid integer
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    address text NOT NULL,
    office_phone character varying(50),
    whatsapp_number character varying(50),
    updated_at timestamp without time zone DEFAULT now(),
    email character varying(255),
    facebook text DEFAULT ''::text,
    instagram text DEFAULT ''::text,
    youtube text DEFAULT ''::text
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: sponsorships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sponsorships (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text DEFAULT ''::text,
    program text NOT NULL,
    message text DEFAULT ''::text,
    status text DEFAULT 'new'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sponsorships_status_check CHECK ((status = ANY (ARRAY['new'::text, 'contacted'::text, 'closed'::text])))
);


--
-- Name: sponsorships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sponsorships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sponsorships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sponsorships_id_seq OWNED BY public.sponsorships.id;


--
-- Name: volunteers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteers (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100),
    phone character varying(20),
    skills text,
    message text,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: volunteers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.volunteers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: volunteers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.volunteers_id_seq OWNED BY public.volunteers.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: activity_photos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_photos ALTER COLUMN id SET DEFAULT nextval('public.activity_photos_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: donations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations ALTER COLUMN id SET DEFAULT nextval('public.donations_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: gallery id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery ALTER COLUMN id SET DEFAULT nextval('public.gallery_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: sponsorships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorships ALTER COLUMN id SET DEFAULT nextval('public.sponsorships_id_seq'::regclass);


--
-- Name: volunteers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers ALTER COLUMN id SET DEFAULT nextval('public.volunteers_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activities (id, title, image_url, category, is_active, created_at, content) FROM stdin;
34	Felicitation on Stage	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image1.png	Community Events	t	2026-09-28 11:44:02.070946	Trust members and guests came together on stage for a felicitation programme. Gifts were exchanged in a warm and respectful atmosphere.\n\nProgrammes like this bring our supporters, volunteers and well wishers closer to the work of the Trust.
33	Education Support in Action	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image2.png	Educational Support	t	2026-09-28 11:44:01.641467	Members of the Trust met with local leaders and presented books and gifts to support learning. Education has always been at the heart of our work.\n\nBooks and study material help students continue their education without worry.
32	Healthcare Camp	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image3.jpeg	Social Welfare	t	2026-09-28 11:44:01.243899	A senior member was honoured with a book at a public gathering. The event was attended by many community members and supporters.\n\nPublic events like this help the Trust reach more people who need its support.
31	Honouring Achievers	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image4.jpeg	Recognition & Outreach	t	2026-09-28 11:44:00.98319	Achievers were recognised with mementos and certificates at a recognition event. Guests and volunteers joined to celebrate their contribution.\n\nRecognition encourages more people to serve society.
30	Gifts for Children	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image5.jpeg	Community Service	t	2026-09-28 11:44:00.647049	Our volunteers distributed gifts to children in the village. The smiles on their faces were the best reward for the whole team.\n\nThe Trust regularly visits communities to support children and families.
29	Community Gathering	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image6.jpeg	Community Events	t	2026-09-28 11:44:00.318939	Community members gathered to honour guests with shawls and flowers. The programme was a chance to meet, share ideas and plan future work together.
28	School Supplies Distribution	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image7.jpeg	Educational Support	t	2026-09-28 11:44:00.014666	School children received notebooks and learning materials from the Trust. Every child deserves the tools to study well.\n\nWe thank all donors who make this help possible.
27	Tribute to Periyar	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image8.jpeg	Recognition & Outreach	t	2026-09-28 11:43:59.682462	Trust members paid respect to Periyar in front of his garlanded portrait. His ideas of equality and self-respect guide everything we do.
26	Sharing the Trust Calendar	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image9.jpeg	Recognition & Outreach	t	2026-09-28 11:43:59.161067	The Trust calendar was presented to supporters. It carries our message of equality and social justice into homes across the region.
25	Courtesy Meeting	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image10.png	Community Events	t	2026-09-28 11:43:58.774364	Members of the Trust held a courtesy meeting and exchanged mementos. Such meetings help build support for the work of the Trust.
24	Meeting and Memento Presentation	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/activities/image11.jpeg	Community Events	t	2026-09-28 11:43:58.258266	A memento was presented during a friendly meeting with community leaders. We value the guidance and support of everyone who stands with us.
\.


--
-- Data for Name: activity_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_photos (id, category, photo_url, r2_key, created_at) FROM stdin;
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_users (id, name, email, password, role, created_at) FROM stdin;
1	Admin	admin@evrperiyartrust.com	$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi	superadmin	2026-09-26 12:04:19.273167
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, name, email, phone, message, is_read, created_at) FROM stdin;
3	mm	hostupto@gmail.com	9876543210	uu	f	2026-09-29 11:36:13.490498
\.


--
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donations (id, donor_name, email, phone, amount, purpose, payment_status, created_at, razorpay_order_id, razorpay_payment_id) FROM stdin;
1	rr	roshinimr670@gmail.com	09677209679	1000.00	General Donation	success	2026-09-26 14:04:06.312753	order_TgbKNVUgLA0twr	pay_TgbKckBEiygBQb
3	we	w@gmail.com	9675560979	500.00	Medical Aid	success	2026-09-26 14:14:11.843747	order_TgbV2I7Btfrlpn	pay_TgbVA90a9KyJLT
2	t	b	6545667	1000.00	General Donation	success	2026-09-26 14:06:24.535593	order_TgbMoTj0J6cBQE	\N
4	Roshini MR	roshinimr670@gmail.com	0677820979	500.00	Education	success	2026-09-26 14:22:33.384027	order_TgbdrqAFEliQdL	pay_TgbdzEKvqZ5oy5
5	edf	dd@gmail.com	9876543210	500.00	General Donation	success	2026-09-29 12:50:04.37423	order_ThlfRia1IynTBq	pay_Thlfg312gLjGUw
6	SD	evrperiyartrust@gmail.com	0444663667	1000.00	General Donation	success	2026-09-30 14:27:41.704186	order_TiBrhhqZ7emab4	pay_TiBs9nIMPhpKSq
7	SD	evrperiyartrust@gmail.com	0444656366	500.00	Medical Aid	success	2026-09-30 14:33:50.894055	order_TiByCe94rDEBTS	pay_TiByU7Vbrn45xT
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, event_date, location, image_url, is_active, created_at, event_time) FROM stdin;
4	Community Food Drive	Essential groceries and food supplies will be distributed to registered families in the area. This is part of our recurring monthly welfare drive.	2026-11-19	Godavari Street, Virugambakkam	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/events/7f173366-cff1-4503-a673-be896051bee1.jpeg	t	2026-09-27 18:13:14.717256	11:00 AM - 2:00 PM
3	School Supplies Drive	We'll be distributing school bags, notebooks, and basic stationery to students from underserved families in the area. Parents/guardians can bring their child's school ID for verification.	2026-10-31	Trust Office, Simmaiya Nagar	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/events/0815e331-76af-432b-967e-f574e5384628.jpeg	t	2026-09-27 18:13:14.717256	10:00 AM - 3:00 PM
2	Free Healthcare Camp	This camp will offer free general checkups, blood pressure and sugar screening, and basic medicine distribution. Volunteers and medical staff will be on-site. All community members are welcome, no registration required.	2026-10-10	Virugambakkam Community Hall, Chennai	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/events/8e19e6e2-5e85-47a8-9677-2163d68fa202.png	t	2026-09-27 18:13:14.717256	9:00 AM - 1:00 PM
\.


--
-- Data for Name: gallery; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gallery (id, title, image_url, created_at) FROM stdin;
2	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/8cf876b0-c994-4d39-8dd8-f0c894263a70.jpeg	2026-09-29 16:37:38.886466
3	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/8df32eb7-7452-4bfc-abb0-9737fa2a87b5.png	2026-09-29 16:37:41.02452
4	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/bd533381-d831-4b77-95a0-842e97aef78d.jpeg	2026-09-29 16:37:41.493122
5	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/4c6b8c54-8462-417a-b771-460adc28fa57.jpeg	2026-09-29 16:37:42.108529
6	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/ff9176d2-a68e-4a2f-af14-7b0e01378fe8.jpeg	2026-09-29 16:37:42.615749
7	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/dc38f3c3-0c83-438c-b6f9-3014b0c96518.jpeg	2026-09-29 16:37:43.156047
8	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/04e7a2f4-7a2d-48a0-b778-34bff0a3afea.jpeg	2026-09-29 16:37:43.682382
9	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/92eb4ce1-4fd2-421d-bd26-acdbc39e55fc.jpeg	2026-09-29 16:37:44.299742
10	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/f2a2aebf-32d1-4e3c-9108-0c6c743da84f.jpeg	2026-09-29 16:37:44.761754
11	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/7f14fb9d-b000-4243-99c7-0164c5ce1502.png	2026-09-29 16:37:46.05471
12	Gallery photo	https://pub-7c8880634fd34ec7b1d3f07bf76603f8.r2.dev/gallery/e7f6a8f9-d18e-48e1-9989-dfa7f4b6d8b0.png	2026-09-29 16:37:46.969932
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, name, father_name, date_of_birth, age, education, voter_id, assembly_constituency, polling_booth, mobile, whatsapp, email, address, pincode, state, city, area, id_photo_url, status, created_at, membership_type, aadhaar, payment_status, utr, member_number, card_token, paid_at, razorpay_order_id, razorpay_payment_id, amount_paid) FROM stdin;
13	roshini	ravi	2003-12-20	22		ABC1234560			9677820979		roshinimr670@gmail.com	swe	629153	Tamil Nadu	Kanyakumari		http://localhost:5000/uploads/member-1790758464273-1fdcba11c669.png	approved	2026-09-30 14:24:24.621569	Life Member	345676543456	paid	\N	EVR130	c6e405fadf7727bf1088a496ef93e1a8342c23f1586787db	2026-09-30 14:25:00.772913+05:30	order_TiBoF4XTjhJ3wP	pay_TiBoVu1oh1qVwy	10000
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.site_settings (id, address, office_phone, whatsapp_number, updated_at, email, facebook, instagram, youtube) FROM stdin;
1	Simmaiya Nagar, Godavari Street\n10-12/126, Virugambakkam\nChennai - 600092	04446563667	9443530390	2026-09-30 15:19:05.042942	evrperiyartrust@gmail.com	https://facebook.com/test	https://instagram.com/test	https://youtube.com/@test
\.


--
-- Data for Name: sponsorships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sponsorships (id, name, email, phone, program, message, status, created_at) FROM stdin;
1	edf	hostupto@gmail.com	9876543210	Education Support		new	2026-09-28 12:55:09.12683+05:30
\.


--
-- Data for Name: volunteers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.volunteers (id, name, email, phone, skills, message, status, created_at) FROM stdin;
1	ww	d@gmail.com	2344543234	Event Support	w	approved	2026-09-27 16:59:18.378684
2	Roshini MR	roshinimr670@gmail.com	+919677209679	Education Support	Tell us about yourself and how you would like to contribute to our community initiatives.Tell us about yourself and how you would like to contribute to our community initiatives.	approved	2026-09-27 17:00:13.780683
3	Roshini MR	roshinimr670@gmail.com	+919677820979	Food & Welfare Drives	Tell us about yourself and how you would like to contribute to our community initiatives.Tell us about yourself and how you would like to contribute to our community initiatives.Tell us about yourself and how you would like to contribute to our community initiatives.	approved	2026-09-27 17:00:52.612765
4	aa	evrperiyartrust@gmail.com	0444656366	Food & Welfare Drives	uioi	approved	2026-09-30 14:35:04.072661
\.


--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activities_id_seq', 39, true);


--
-- Name: activity_photos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_photos_id_seq', 1, false);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contacts_id_seq', 3, true);


--
-- Name: donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.donations_id_seq', 7, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.events_id_seq', 5, true);


--
-- Name: gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gallery_id_seq', 14, true);


--
-- Name: member_number_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_number_seq', 130, true);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 13, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 1, true);


--
-- Name: sponsorships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sponsorships_id_seq', 3, true);


--
-- Name: volunteers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.volunteers_id_seq', 4, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: activity_photos activity_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_photos
    ADD CONSTRAINT activity_photos_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_email_key UNIQUE (email);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: gallery gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery
    ADD CONSTRAINT gallery_pkey PRIMARY KEY (id);


--
-- Name: members members_card_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_card_token_key UNIQUE (card_token);


--
-- Name: members members_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_email_key UNIQUE (email);


--
-- Name: members members_member_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_member_number_key UNIQUE (member_number);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: members members_razorpay_payment_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_razorpay_payment_id_key UNIQUE (razorpay_payment_id);


--
-- Name: members members_utr_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_utr_key UNIQUE (utr);


--
-- Name: members members_utr_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_utr_unique UNIQUE (utr);


--
-- Name: members members_voter_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_voter_id_key UNIQUE (voter_id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: sponsorships sponsorships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sponsorships
    ADD CONSTRAINT sponsorships_pkey PRIMARY KEY (id);


--
-- Name: volunteers volunteers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT volunteers_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict mDN3Yc3Okr4W7n5pEHJSmyvqRfVVV2OKpPqxwM9mbi6cggymxGaNjAnOWnzufMA

